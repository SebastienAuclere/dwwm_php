<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentification</title>
</head>
<body>
    <style>
        form { width: 800px; margin: auto; }
        label { display:inline-block; width: 200px;}
        div { margin: 10px; }
    </style>
    <h2>Connexion</h2>
    <form action="auth.php" method="POST">
        <div>
            <label for="email">Ton adresse email</label>
            <input type="email" name="email" id="email">
        </div>
        <div>
            <label for="password">Ton mot de passe</label>
            <input type="password" name="password" id="password">
        </div>
        <div>
            <button type="submit">Connexion</button>
        </div>
    </form>
</body>
</html>