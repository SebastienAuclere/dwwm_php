<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        form { width: 800px; margin: auto; }
        label { display:inline-block; width: 200px;}
        div { margin: 10px; }
    </style>
</head>
<body>
    <h1>Ajouter un scientifique</h1>
    <form action="./ajouter-scientifique-traitement.php" method="POST">
        <div>
            <label for="lastname">Nom</label>
            <input type="text" name="lastname" id="lastname">
        </div>
        <div>
            <label for="firstname">Prénom</label>
            <input type="text" name="firstname" id="firstname">
        </div>
        <div>
            <label for="email">Email</label>
            <input type="email" name="email" id="email">
        </div>
        <div>
            <label for="password">Mot de passe</label>
            <input type="password" name="password" id="password">
        </div>
        <div>
            <label for="password2">Répéter Mot de passe</label>
            <input type="password" name="password2" id="password2">
        </div>
        <div>
            <label for="level">Level</label> 
            <input type="number" id="level" name="level" placeholder="level">
        </div>
        <div>
            <button type="submit">Ajouter</button>
        </div>
    </form>
    
</body>
</html>